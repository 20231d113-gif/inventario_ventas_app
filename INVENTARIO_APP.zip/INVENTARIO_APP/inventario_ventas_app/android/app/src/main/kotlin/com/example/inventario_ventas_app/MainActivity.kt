package com.example.inventario_ventas_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
